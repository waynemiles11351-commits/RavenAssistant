import ActivityKit
import SwiftUI
import WidgetKit

struct RavenWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: RavenLiveActivityAttributes.self) { context in
            VStack(alignment: .leading, spacing: 6) {
                HStack { Text("🐦 渡鸦").font(.headline); Spacer(); Text("\(context.state.confidence)%") }
                Text(context.state.phase).font(.subheadline)
                HStack { Text("关注"); Text(context.state.targetName).bold(); Spacer(); Text("存活 \(context.state.aliveCount > 0 ? "\(context.state.aliveCount)" : "—")") }
                Text(context.state.suggestion).font(.caption).lineLimit(2).foregroundStyle(.secondary)
            }
            .padding()
            .activityBackgroundTint(.black)
            .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    VStack(alignment: .leading) { Text("🐦 渡鸦").font(.headline); Text(context.state.phase).font(.caption) }
                }
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing) { Text("\(context.state.confidence)%").bold(); Text("\(context.state.aliveCount > 0 ? "\(context.state.aliveCount)" : "—")人").font(.caption) }
                }
                DynamicIslandExpandedRegion(.center) {
                    VStack { Text(context.state.targetName).font(.title3.bold()); Text(context.state.suggestion).font(.caption).lineLimit(2) }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("屏幕识别仅接受高置信度状态更新").font(.caption2).foregroundStyle(.secondary)
                }
            } compactLeading: {
                Text("🐦")
            } compactTrailing: {
                Text("\(context.state.confidence)%")
            } minimal: {
                Text("🐦")
            }
            .widgetURL(URL(string: "raven://session"))
            .keylineTint(.white)
        }
    }
}

@main
struct RavenWidgetBundle: WidgetBundle {
    var body: some Widget { RavenWidget() }
}
