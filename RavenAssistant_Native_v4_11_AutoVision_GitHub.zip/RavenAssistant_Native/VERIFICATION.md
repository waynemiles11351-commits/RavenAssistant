# Verification checklist

代码层已检查：
- 角色数据库 67 条，62 current + 5 legacy/map-specific。
- 新增 RoleCatalog / EventRuleEngine / RoleInferenceEngine 文件已加入 xcodeproj。
- Info.plist 声明 NSScreenCaptureUsageDescription + screen-capture background mode。
- OCR 识别增加中英文角色名 customWords。
- 角色推理支持直接身份证据、事件证据、矛盾、时间衰减、Top-3。
- 事件支持去重，避免每帧重复写日志。

当前环境没有 Xcode/macOS 真机工具链，因此未宣称完成 iPhone 真机编译、屏幕采集、Dynamic Island 或实际游戏画面的端到端验证。
