import XCTest
@testable import RavenAssistant

final class RoleCatalogTests: XCTestCase {
    func testRoleCatalogBaseline() throws {
        let roles = RoleCatalog.shared.roles
        XCTAssertEqual(roles.count, 67)
        XCTAssertEqual(roles.filter { $0.availability == "current" }.count, 62)
        XCTAssertEqual(roles.filter { $0.availability == "legacy-or-map-specific" }.count, 5)
        XCTAssertNotNil(RoleCatalog.shared.role(id: "swordsman-duck"))
        XCTAssertNotNil(RoleCatalog.shared.role(id: "magpie"))
        XCTAssertNotNil(RoleCatalog.shared.role(id: "cuckoo"))
        XCTAssertNotNil(RoleCatalog.shared.role(id: "parasite"))
    }

    func testTextAnalyzerDetectsStandingBody() throws {
        let analyzer = VisionAnalyzer()
        let state = analyzer.analyzeTextForTesting(["投票", "尸体保持站立", "Swordsman Duck"])
        XCTAssertEqual(state?.phase, "投票")
        XCTAssertTrue(state?.events.contains(where: { $0.kind == "尸体保持站立" }) == true)
    }

    func testTextAnalyzerDetectsRoleReveal() throws {
        let analyzer = VisionAnalyzer()
        let state = analyzer.analyzeTextForTesting(["你的身份", "加拿大鹅"])
        XCTAssertEqual(state?.phase, "身份揭示")
        XCTAssertEqual(state?.hypotheses.first?.roleID, "canadian")
    }
}
