import ActivityKit
import Foundation

public struct RavenLiveActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        public var phase: String
        public var targetName: String
        public var confidence: Int
        public var aliveCount: Int
        public var suggestion: String
        public var alertLevel: String

        public init(phase: String, targetName: String, confidence: Int, aliveCount: Int, suggestion: String, alertLevel: String) {
            self.phase = phase
            self.targetName = targetName
            self.confidence = confidence
            self.aliveCount = aliveCount
            self.suggestion = suggestion
            self.alertLevel = alertLevel
        }
    }

    public var sessionID: String
    public var gameVersion: String
    public var mode: String

    public init(sessionID: String, gameVersion: String, mode: String) {
        self.sessionID = sessionID
        self.gameVersion = gameVersion
        self.mode = mode
    }
}
