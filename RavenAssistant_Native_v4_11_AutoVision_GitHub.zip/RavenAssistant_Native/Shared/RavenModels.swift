import Foundation
import CoreGraphics

public enum RavenFaction: String, Codable, CaseIterable {
    case goose = "Goose"
    case duck = "Duck"
    case neutral = "Neutral"
}

public enum RavenPhase: String, Codable, CaseIterable {
    case unknown
    case lobby
    case roleReveal
    case action
    case meeting
    case voting
    case results
}

public enum RavenEvidenceKind: String, Codable, CaseIterable {
    case directRole = "直接身份"
    case visualSignal = "视觉信号"
    case event = "事件"
    case timing = "时间关系"
    case contradiction = "矛盾"
    case roster = "玩家列表"
}

public struct RavenRole: Codable, Hashable, Identifiable {
    public let id: String
    public let nameCN: String
    public let nameEN: String
    public let faction: RavenFaction
    public let mode: String
    public let canKill: Bool
    public let canVote: Bool
    public let ability: String
    public let winCondition: String
    public let signals: [String]
    public let specialInteractions: [String]
    public let availability: String
    public let source: String

    public init(id: String, nameCN: String, nameEN: String, faction: RavenFaction, mode: String, canKill: Bool, canVote: Bool, ability: String, winCondition: String, signals: [String], specialInteractions: [String], availability: String, source: String) {
        self.id = id; self.nameCN = nameCN; self.nameEN = nameEN; self.faction = faction; self.mode = mode
        self.canKill = canKill; self.canVote = canVote; self.ability = ability; self.winCondition = winCondition
        self.signals = signals; self.specialInteractions = specialInteractions; self.availability = availability; self.source = source
    }
}

public struct RavenEvent: Identifiable, Codable, Hashable {
    public let id: UUID
    public let time: Date
    public let kind: String
    public let player: String?
    public let detail: String
    public let confidence: Double

    public init(id: UUID = UUID(), time: Date = .now, kind: String, player: String? = nil, detail: String, confidence: Double) {
        self.id = id; self.time = time; self.kind = kind; self.player = player; self.detail = detail; self.confidence = confidence
    }
}

public struct RavenOCRToken: Hashable, Sendable {
    public let text: String
    public let confidence: Double
    public let boundingBox: CGRect

    public init(text: String, confidence: Double, boundingBox: CGRect) {
        self.text = text; self.confidence = confidence; self.boundingBox = boundingBox
    }
}

public struct RavenDetectedSignal: Hashable, Sendable {
    public let id: String
    public let label: String
    public let confidence: Double
    public let evidenceText: String

    public init(id: String, label: String, confidence: Double, evidenceText: String) {
        self.id = id; self.label = label; self.confidence = confidence; self.evidenceText = evidenceText
    }
}

public struct RavenRoleHypothesis: Identifiable, Hashable, Sendable {
    public let id: String
    public let roleID: String
    public let roleName: String
    public let faction: RavenFaction
    public let confidence: Double
    public let reasons: [String]

    public init(role: RavenRole, confidence: Double, reasons: [String]) {
        self.id = role.id
        self.roleID = role.id
        self.roleName = role.nameCN
        self.faction = role.faction
        self.confidence = confidence
        self.reasons = reasons
    }
}

public struct RavenPlayerInference: Identifiable, Hashable, Sendable {
    public let id: String
    public let playerName: String
    public let alive: Bool
    public let topRoles: [RavenRoleHypothesis]
    public let factionConfidence: [RavenFaction: Double]

    public init(id: String, playerName: String, alive: Bool, topRoles: [RavenRoleHypothesis], factionConfidence: [RavenFaction: Double]) {
        self.id = id; self.playerName = playerName; self.alive = alive; self.topRoles = topRoles; self.factionConfidence = factionConfidence
    }
}

public struct RavenAnalyzerOutput: Sendable {
    public let phase: RavenPhase
    public let aliveCount: Int
    public let screenConfidence: Double
    public let targetName: String?
    public let targetHypotheses: [RavenRoleHypothesis]
    public let players: [RavenPlayerInference]
    public let signals: [RavenDetectedSignal]
    public let events: [RavenEvent]
    public let suggestion: String
    public let detail: String

    public init(phase: RavenPhase, aliveCount: Int, screenConfidence: Double, targetName: String?, targetHypotheses: [RavenRoleHypothesis], players: [RavenPlayerInference], signals: [RavenDetectedSignal], events: [RavenEvent], suggestion: String, detail: String) {
        self.phase = phase; self.aliveCount = aliveCount; self.screenConfidence = screenConfidence
        self.targetName = targetName; self.targetHypotheses = targetHypotheses; self.players = players
        self.signals = signals; self.events = events; self.suggestion = suggestion; self.detail = detail
    }
}
