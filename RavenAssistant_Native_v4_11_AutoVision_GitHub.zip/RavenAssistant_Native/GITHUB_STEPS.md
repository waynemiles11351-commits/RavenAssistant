# 只用 iPhone 操作 GitHub 构建

你不需要 Mac。下面这套流程使用 GitHub 的 macOS runner 编译工程。公开仓库使用标准 GitHub-hosted runners 时，GitHub Actions 的标准 runner 使用免费且不限量。

## 1. 创建 GitHub 仓库

用 iPhone Safari 打开：
https://github.com/new

Repository name：
`RavenAssistant`

Visibility：
`Public`

可以勾选 `Add a README file`，然后点 `Create repository`。

## 2. 上传工程 ZIP

先把这个工程 ZIP 保存到 iPhone“文件”App。

仓库主页 → `Add file` → `Upload files`。

上传：
`RavenAssistant_Native_v4_11_AutoVision_GitHub.zip`

然后点 `Commit changes`。

## 3. 建立 Actions 文件

仓库主页 → `Add file` → `Create new file`。

文件名完整填写：
`.github/workflows/ios-build.yml`

把 ZIP 里的同名文件内容粘贴进去，点 `Commit changes`。

## 4. 启动构建

进入仓库 → `Actions` → `Raven Assistant iOS Build` → `Run workflow` → `Run workflow`。

成功以后进入该次运行，在页面底部找到 `Artifacts`，下载：
`raven-assistant-builds`

里面有：
- `RavenAssistant-device-unsigned.zip`
- `RavenAssistant-simulator.zip`

## 5. 必须知道的限制

上面的 device 包是“未签名编译产物”，用于验证工程能够通过 Apple SDK 编译，并不能直接安装到你的 iPhone。

真正安装到 iPhone / TestFlight，还需要 Apple 的签名与 App Store Connect 分发条件。Apple 官方说明，TestFlight build 必须带有 provisioning profile 中的 application identifier，并通过 App Store Connect 分发。

所以在你只有 iPhone、没有 Mac/iPad 且不付费的情况下，GitHub 能免费帮我们完成的是：
`代码 → macOS 编译 → 编译结果/错误日志`

它本身不能绕过 Apple 的签名和分发要求。

## 6. 安全

不要把 Apple 私钥、证书、API 密钥或密码直接写进公开仓库。GitHub 官方也明确建议不要把密码/API key 等敏感信息提交到仓库。
