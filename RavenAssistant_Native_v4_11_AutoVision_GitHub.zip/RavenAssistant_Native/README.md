# 渡鸦助手 Native v4.11 · Auto Vision Edition

这是原生 iOS 版本骨架，目标是：用户主动授权屏幕采集后，由 ScreenCaptureKit 获取整个屏幕，Vision OCR 提取公开 UI 文本，再由事件规则与角色推理引擎累积证据，并通过 ActivityKit/WidgetKit 更新 Dynamic Island。

## 已实现的逻辑层

- 67 条角色记录：62 个当前公开角色 + 5 个 legacy/map-specific 记录。
- `EventRuleEngine`：会议、尸体、变形、通风、隐形、连杀、站立尸体、布谷蛋、身份猜测、巫医标记、寄生、自动报告、网红提示、梦境、渡鸦/布谷狩猎等公开 UI 事件锚点。
- `RoleInferenceEngine`：支持直接身份揭示、事件证据、视觉信号、矛盾证据、时间衰减、Top-3 候选。
- `VisionAnalyzer`：Vision OCR、阶段判断、存活人数 OCR、事件去重、低置信度不强制锁定。
- `GameSessionStore`：把分析结果实时推到 UI 和 Live Activity。

## 重要限制

隐藏身份不是单靠 OCR 就能“直接读取”。当屏幕没有公开给玩家的信息时，助手只能根据可见事件进行概率式推断。只有角色揭示画面或其他公开身份 UI 出现时，才会产生接近确定性的直接证据。

本项目不修改游戏进程、不注入、不读取游戏内存、不自动操作角色。

## 运行环境

工程基线：iOS 27+ / Xcode 26+。

Apple 当前 ScreenCaptureKit 文档说明：iOS 屏幕捕获通过系统 `SCContentSharingPicker` 由用户选择捕获内容，并可用 `screen-capture` 背景模式让全屏流在 App 不在前台时继续运行。工程已声明 `NSScreenCaptureUsageDescription` 与 `UIBackgroundModes=screen-capture`。

### 使用步骤

1. Mac 安装 Xcode 26+。
2. 打开 `RavenAssistant.xcodeproj`。
3. 在 Signing & Capabilities 里选择你自己的 Team，并把 Bundle Identifier 改成唯一值。
4. 连接 iPhone，目标设备选择 iPhone 真机。
5. `Product -> Run` 安装。
6. 第一次打开 App，进入“战局”，点“开始辅助”。
7. 在 iOS 系统的屏幕共享/录制选择器里选择“整个屏幕”，完成授权。
8. 保持 Live Activity 开启，然后切换进入《鹅鸭杀》。
9. 当游戏 UI 出现会议、投票、角色揭示等公开文字/视觉信号时，渡鸦会自动更新事件、阶段和角色候选。
10. 长按 Dynamic Island 查看当前候选及最近状态。

## 真机验证前检查

- 屏幕采集弹窗能正常出现。
- 切出到游戏后，`screen-capture` 背景流继续输出。
- Live Activity 能启动和更新。
- 视觉识别测试页/单元测试中的中文、英文锚点能命中。
- 不要把“候选角色”当成读取到了隐藏数据；它只是基于当前可见证据的推断。


## 无 Mac：GitHub Actions

请先阅读 `GITHUB_STEPS.md`。
