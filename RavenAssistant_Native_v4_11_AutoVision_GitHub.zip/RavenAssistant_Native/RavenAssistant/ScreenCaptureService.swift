import AVFoundation
import CoreMedia
import Foundation
import ScreenCaptureKit

@MainActor
final class ScreenCaptureService: NSObject, ObservableObject, SCContentSharingPickerObserver, SCStreamDelegate, SCStreamOutput {
    @Published private(set) var isCapturing = false
    @Published private(set) var status = "未启动"

    private let picker = SCContentSharingPicker.shared
    private var stream: SCStream?
    private var frameHandler: ((CMSampleBuffer) -> Void)?
    private let queue = DispatchQueue(label: "raven.screen.capture", qos: .userInitiated)

    override init() {
        super.init()
        picker.add(self)
    }

    func start(frameHandler: @escaping (CMSampleBuffer) -> Void) async {
        self.frameHandler = frameHandler
        var configuration = picker.defaultConfiguration
        configuration.allowedPickerModes = .singleDisplay
        configuration.allowsChangingSelectedContent = false
        configuration.showsMicrophoneControl = false
        picker.defaultConfiguration = configuration
        picker.isActive = true
        status = "请在系统弹窗中选择整个屏幕"
        picker.present(using: .display)
    }

    func stop() async {
        picker.isActive = false
        if let stream {
            try? await stream.stopCapture()
        }
        stream = nil
        frameHandler = nil
        isCapturing = false
        status = "已停止"
    }

    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker, didUpdateWith filter: SCContentFilter, for stream: SCStream?) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            await self.installStream(filter: filter)
        }
    }

    nonisolated func contentSharingPicker(_ picker: SCContentSharingPicker, didCancelFor stream: SCStream?) {
        Task { @MainActor [weak self] in self?.status = "已取消屏幕授权" }
    }

    nonisolated func contentSharingPickerStartDidFailWithError(_ error: any Error) {
        Task { @MainActor [weak self] in self?.status = "屏幕捕获失败：\(error.localizedDescription)" }
    }

    private func installStream(filter: SCContentFilter) async {
        if let old = stream { try? await old.stopCapture() }
        let config = SCStreamConfiguration()
        config.capturesAudio = false
        config.captureMicrophone = false
        config.captureResolution = .automatic
        config.captureDynamicRange = .SDR
        config.showMouseClicks = false
        config.showsCursor = false
        config.minimumFrameInterval = CMTime(value: 1, timescale: 5) // 5 FPS baseline; Vision can throttle further.
        let newStream = SCStream(filter: filter, configuration: config, delegate: self)
        do {
            try newStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
            try await newStream.startCapture()
            stream = newStream
            isCapturing = true
            status = "正在读取屏幕（本地处理）"
        } catch {
            status = "启动失败：\(error.localizedDescription)"
        }
    }

    nonisolated func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of outputType: SCStreamOutputType) {
        guard outputType == .screen, sampleBuffer.isValid else { return }
        frameHandler?(sampleBuffer)
    }

    nonisolated func stream(_ stream: SCStream, didStopWithError error: any Error) {
        Task { @MainActor [weak self] in
            self?.isCapturing = false
            self?.status = "屏幕流已停止：\(error.localizedDescription)"
        }
    }
}
