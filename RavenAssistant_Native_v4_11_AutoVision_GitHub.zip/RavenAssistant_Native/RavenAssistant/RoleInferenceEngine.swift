import Foundation

struct RavenEvidence: Hashable, Sendable {
    let playerName: String
    let roleID: String
    let weight: Double
    let kind: RavenEvidenceKind
    let reason: String
    let timestamp: Date
}

final class RoleInferenceEngine {
    private var evidence: [String: [String: [RavenEvidence]]] = [:]
    private let catalog = RoleCatalog.shared
    private let queue = DispatchQueue(label: "raven.role.inference")
    private let maxHistory = 120

    func reset() {
        queue.sync { evidence.removeAll(keepingCapacity: true) }
    }

    func addEvidence(playerName: String, roleID: String, weight: Double, kind: RavenEvidenceKind, reason: String, now: Date = .now) {
        let name = normalizedPlayer(playerName)
        guard !name.isEmpty, catalog.role(id: roleID) != nil else { return }
        queue.sync {
            evidence[name, default: [:]][roleID, default: []].append(
                RavenEvidence(playerName: playerName, roleID: roleID, weight: min(max(weight, -1), 1), kind: kind, reason: reason, timestamp: now)
            )
            if evidence[name]?[roleID]?.count ?? 0 > maxHistory {
                evidence[name]?[roleID]?.removeFirst()
            }
        }
    }

    func addDirectRole(playerName: String, roleID: String, confidence: Double, reason: String) {
        addEvidence(playerName: playerName, roleID: roleID, weight: max(0.85, confidence), kind: .directRole, reason: reason)
        // A direct reveal is strong positive evidence and strong negative evidence for alternatives.
        queue.sync {
            guard let roles = evidence[nameKey(playerName)] else { return }
            let ids = catalog.roles.map(\.id)
            for roleID2 in ids where roleID2 != roleID {
                evidence[nameKey(playerName), default: [:]][roleID2, default: []].append(
                    RavenEvidence(playerName: playerName, roleID: roleID2, weight: -0.55, kind: .contradiction, reason: "同一画面直接显示其他身份", timestamp: .now)
                )
            }
            _ = roles
        }
    }

    func infer(playerName: String, topK: Int = 3, activeMode: String? = nil) -> [RavenRoleHypothesis] {
        queue.sync { inferLocked(playerName: playerName, topK: topK, activeMode: activeMode, now: .now) }
    }

    func inferMany(playerNames: [String], activeMode: String? = nil) -> [RavenPlayerInference] {
        queue.sync {
            playerNames.compactMap { name in
                let ranked = inferLocked(playerName: name, topK: 3, activeMode: activeMode, now: .now)
                guard !ranked.isEmpty else { return nil }
                let factionScores = RavenFaction.allCases.reduce(into: [RavenFaction: Double]()) { result, faction in
                    let roleScores = catalog.roles.filter { $0.faction == faction }.map { scoreLocked(playerName: name, roleID: $0.id, now: .now) }
                    result[faction] = normalizeConfidence(roleScores.max() ?? 0)
                }
                return RavenPlayerInference(id: nameKey(name), playerName: name, alive: true, topRoles: ranked, factionConfidence: factionScores)
            }
        }
    }

    private func inferLocked(playerName: String, topK: Int, activeMode: String?, now: Date) -> [RavenRoleHypothesis] {
        let available = catalog.roles.filter { activeMode == nil || $0.mode.localizedCaseInsensitiveContains(activeMode!) || $0.mode.localizedCaseInsensitiveContains("Classic") }
        let ranked = available.map { role -> (RavenRole, Double, [String]) in
            let entries = evidence[nameKey(playerName)]?[role.id] ?? []
            let positives = entries.map { weighted($0, now: now) }.reduce(0, +)
            let score = positives
            let reasons = entries.sorted { weighted($0, now: now) > weighted($1, now: now) }
                .prefix(3).map(\.reason)
            return (role, score, reasons.isEmpty ? ["暂无直接证据"] : reasons)
        }
        .sorted { $0.1 > $1.1 }

        guard let top = ranked.first else { return [] }
        let rawScores = ranked.prefix(max(topK, 3)).map { $0.1 }
        let maxScore = max(0.01, top.1)
        let margin = max(0, top.1 - (ranked.dropFirst().first?.1 ?? 0))
        return ranked.prefix(topK).map { item in
            let relative = max(0, item.1) / maxScore
            let confidence = min(0.98, max(0.05, 0.18 + 0.62 * relative + 0.20 * min(1, margin)))
            _ = rawScores
            return RavenRoleHypothesis(role: item.0, confidence: confidence, reasons: item.2)
        }
    }

    private func scoreLocked(playerName: String, roleID: String, now: Date) -> Double {
        (evidence[nameKey(playerName)]?[roleID] ?? []).map { weighted($0, now: now) }.reduce(0, +)
    }

    private func weighted(_ evidence: RavenEvidence, now: Date) -> Double {
        let age = max(0, now.timeIntervalSince(evidence.timestamp))
        let decay = pow(0.5, age / (60 * 8)) // half-life 8 minutes
        return evidence.weight * decay
    }

    private func normalizeConfidence(_ score: Double) -> Double {
        max(0, min(0.99, 0.5 + score * 0.25))
    }

    private func normalizedPlayer(_ name: String) -> String { nameKey(name) }
    private func nameKey(_ name: String) -> String { name.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current).trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
}
