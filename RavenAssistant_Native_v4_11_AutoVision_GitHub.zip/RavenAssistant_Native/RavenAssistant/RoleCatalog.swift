import Foundation

final class RoleCatalog {
    static let shared = RoleCatalog()
    let roles: [RavenRole]
    private let roleByID: [String: RavenRole]

    private init() {
        guard let url = Bundle.main.url(forResource: "role_catalog", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode(RoleCatalogFile.self, from: data) else {
            roles = []
            roleByID = [:]
            return
        }
        let parsed = decoded.roles.compactMap { raw -> RavenRole? in
            guard let faction = RavenFaction(rawValue: raw.faction) else { return nil }
            return RavenRole(id: raw.id, nameCN: raw.nameCN, nameEN: raw.nameEN, faction: faction, mode: raw.mode,
                             canKill: raw.canKill, canVote: raw.canVote, ability: raw.ability,
                             winCondition: raw.winCondition, signals: raw.signals, specialInteractions: raw.specialInteractions,
                             availability: raw.availability, source: raw.source)
        }
        roles = parsed
        roleByID = Dictionary(uniqueKeysWithValues: parsed.map { ($0.id, $0) })
    }

    func role(id: String) -> RavenRole? { roleByID[id] }

    func role(matching text: String) -> RavenRole? {
        let normalized = normalize(text)
        return roles
            .sorted { ($0.nameCN.count + $0.nameEN.count) > ($1.nameCN.count + $1.nameEN.count) }
            .first { normalized.contains(normalize($0.nameCN)) || normalized.localizedCaseInsensitiveContains(normalize($0.nameEN)) }
    }

    func roles(matchingAny texts: [String]) -> [RavenRole] {
        let joined = normalize(texts.joined(separator: " "))
        return roles.filter { role in
            joined.contains(normalize(role.nameCN)) || joined.localizedCaseInsensitiveContains(normalize(role.nameEN))
        }
    }

    static func normalize(_ text: String) -> String {
        text.replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "\n", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }
}

private struct RoleCatalogFile: Decodable { let roles: [RoleRaw] }
private struct RoleRaw: Decodable {
    let id: String; let nameCN: String; let nameEN: String; let faction: String; let mode: String
    let canKill: Bool; let canVote: Bool; let ability: String; let winCondition: String
    let signals: [String]; let specialInteractions: [String]; let availability: String; let source: String
}
