import Foundation

struct RavenRuleMatch: Sendable {
    let eventID: String
    let label: String
    let confidence: Double
    let evidenceText: String
    let possibleRoleIDs: [String]
}

final class EventRuleEngine {
    private struct Rule {
        let id: String
        let label: String
        let anchors: [String]
        let roleIDs: [String]
        let weight: Double
    }

    private let rules: [Rule] = [
        Rule(id: "meeting", label: "会议开始", anchors: ["投票", "VOTING", "跳过", "SKIP"], roleIDs: [], weight: 0.86),
        Rule(id: "body", label: "发现尸体/报告", anchors: ["尸体", "REPORT", "报告", "WHO REPORTED"], roleIDs: ["canadian", "professional", "sheriff"], weight: 0.88),
        Rule(id: "morph", label: "外貌变化", anchors: ["改变外貌", "变形", "MORPH", "APPEARANCE CHANGE"], roleIDs: ["morphling", "parasite"], weight: 0.95),
        Rule(id: "vent", label: "通风管行为", anchors: ["通风", "VENT"], roleIDs: ["engineer", "morphling", "identity-thief", "parasite"], weight: 0.80),
        Rule(id: "teleport", label: "传送行为", anchors: ["传送", "TELEPORT"], roleIDs: ["detective", "engineer", "astral"], weight: 0.66),
        Rule(id: "invisibility", label: "隐形行为", anchors: ["隐形", "INVISIBLE", "INVISIBILITY"], roleIDs: ["invisibility", "ninja"], weight: 0.95),
        Rule(id: "double-kill", label: "短时间连续击杀", anchors: ["双杀", "DOUBLE KILL", "多杀"], roleIDs: ["ninja", "swordsman-duck", "avenger"], weight: 0.80),
        Rule(id: "standing-body", label: "尸体保持站立", anchors: ["尸体保持站立", "STANDING BODY"], roleIDs: ["swordsman-duck"], weight: 0.98),
        Rule(id: "egg", label: "布谷鸟蛋", anchors: ["布谷蛋", "CUCKOO EGG", "EGG"], roleIDs: ["cuckoo"], weight: 0.70),
        Rule(id: "role-guess", label: "会议身份猜测", anchors: ["猜身份", "GUESS ROLE", "ROLE GUESS"], roleIDs: ["magpie", "assassin"], weight: 0.79),
        Rule(id: "curse-eye", label: "诅咒/X 光目标标记", anchors: ["诅咒", "X光", "X-RAY", "CURSED", "EYE MARK"], roleIDs: ["witch-doctor"], weight: 0.92),
        Rule(id: "parasite", label: "寄生/宿主异常", anchors: ["寄生", "PARASITE", "HOST"], roleIDs: ["carrier", "parasite"], weight: 0.94),
        Rule(id: "auto-report", label: "延迟自动报告", anchors: ["自动报告", "AUTO REPORT", "DELAYED REPORT"], roleIDs: ["canadian"], weight: 0.92),
        Rule(id: "celebrity-alert", label: "全鹅死亡提示", anchors: ["死亡提示", "DEATH ALERT", "CELEBRITY"], roleIDs: ["celebrity"], weight: 0.90),
        Rule(id: "dream", label: "会议梦境", anchors: ["梦境", "LUCID DREAM", "DREAM"], roleIDs: ["lucid-dreamer"], weight: 0.96),
        Rule(id: "raven-hunt", label: "渡鸦狩猎阶段", anchors: ["渡鸦狩猎", "RAVEN HUNT"], roleIDs: ["raven"], weight: 0.98),
        Rule(id: "cuckoo-hunt", label: "布谷狩猎阶段", anchors: ["布谷狩猎", "CUCKOO HUNT"], roleIDs: ["cuckoo"], weight: 0.98)
    ]

    func detect(tokens: [RavenOCRToken]) -> [RavenRuleMatch] {
        let text = tokens.map(\.text).joined(separator: " ")
        let normalized = RoleCatalog.normalize(text)
        var matches = rules.compactMap { rule -> RavenRuleMatch? in
            let matched = rule.anchors.first { anchor in
                normalized.contains(RoleCatalog.normalize(anchor))
            }
            guard let matched else { return nil }
            let confidence = min(0.99, rule.weight * (0.75 + 0.25 * averageOCRConfidence(tokens)))
            return RavenRuleMatch(eventID: rule.id, label: rule.label, confidence: confidence, evidenceText: matched, possibleRoleIDs: rule.roleIDs)
        }

        // Generic role-signal expansion: every role in the database can contribute
        // evidence without requiring a hand-written rule for every future signal.
        for role in RoleCatalog.shared.roles where role.availability == "current" {
            for signal in role.signals where signal.count >= 2 {
                let n = RoleCatalog.normalize(signal)
                guard n.count >= 2, normalized.contains(n) else { continue }
                matches.append(RavenRuleMatch(
                    eventID: "role-signal-\(role.id)-\(n)",
                    label: "\(role.nameCN) 信号",
                    confidence: min(0.88, 0.58 + 0.28 * averageOCRConfidence(tokens)),
                    evidenceText: signal,
                    possibleRoleIDs: [role.id]
                ))
                break
            }
        }

        return deduplicated(matches)
    }

    private func deduplicated(_ matches: [RavenRuleMatch]) -> [RavenRuleMatch] {
        var best: [String: RavenRuleMatch] = [:]
        for match in matches {
            if match.confidence > (best[match.eventID]?.confidence ?? 0) {
                best[match.eventID] = match
            }
        }
        return best.values.sorted { $0.confidence > $1.confidence }
    }

    private func averageOCRConfidence(_ tokens: [RavenOCRToken]) -> Double {
        guard !tokens.isEmpty else { return 0.5 }
        return tokens.map(\.confidence).reduce(0, +) / Double(tokens.count)
    }
}
