import SwiftUI

@main
struct RavenAssistantApp: App {
    @StateObject private var session = GameSessionStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(session)
                .preferredColorScheme(.dark)
        }
    }
}
