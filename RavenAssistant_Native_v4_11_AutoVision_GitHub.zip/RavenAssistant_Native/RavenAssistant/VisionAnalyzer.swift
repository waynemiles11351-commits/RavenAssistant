import CoreImage
import CoreMedia
import Foundation
import Vision
import UIKit

struct AnalyzerState: Sendable {
    let kind: String
    let phase: String
    let targetName: String?
    let confidence: Double
    let aliveCount: Int
    let suggestion: String
    let detail: String
    let hypotheses: [RavenRoleHypothesis]
    let players: [RavenPlayerInference]
    let events: [RavenEvent]
}

final class VisionAnalyzer {
    private let catalog = RoleCatalog.shared
    private let ruleEngine = EventRuleEngine()
    private let inference = RoleInferenceEngine()
    private let lock = NSLock()
    private var lastRun = Date.distantPast
    private var lastPhase: RavenPhase = .unknown
    private var lastEventIDs: [String: Date] = [:]

    func reset() {
        lock.lock(); defer { lock.unlock() }
        lastRun = .distantPast
        lastPhase = .unknown
        lastEventIDs.removeAll()
        inference.reset()
    }

    func analyze(_ sample: CMSampleBuffer) -> AnalyzerState? {
        guard shouldRun() else { return nil }
        guard let pixel = CMSampleBufferGetImageBuffer(sample) else { return nil }

        let image = CIImage(cvPixelBuffer: pixel)
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        request.minimumTextHeight = 0.010
        request.recognitionLanguages = ["zh-Hans", "zh-Hant", "en-US"]
        request.customWords = catalog.roles.flatMap { [$0.nameCN, $0.nameEN] }

        let handler = VNImageRequestHandler(ciImage: image, options: [:])
        do { try handler.perform([request]) } catch { return nil }
        let tokens = request.results?.compactMap { observation -> RavenOCRToken? in
            guard let candidate = observation.topCandidates(1).first else { return nil }
            return RavenOCRToken(text: candidate.string, confidence: Double(candidate.confidence), boundingBox: observation.boundingBox)
        } ?? []
        return analyzeTokens(tokens)
    }

    // Text-only entry point used for regression tests and offline debugging.
    func analyzeTextForTesting(_ texts: [String]) -> AnalyzerState? {
        let tokens = texts.map { RavenOCRToken(text: $0, confidence: 0.95, boundingBox: .zero) }
        return analyzeTokens(tokens)
    }

    private func analyzeTokens(_ tokens: [RavenOCRToken]) -> AnalyzerState? {
        let joined = tokens.map(\.text).joined(separator: " ")
        let phase = detectPhase(joined)
        let alive = detectAliveCount(tokens)
        let roleHits = catalog.roles(matchingAny: tokens.map(\.text))
        let ruleMatches = ruleEngine.detect(tokens: tokens)

        applyExplicitKillEvidence(tokens: tokens, ruleMatches: ruleMatches)

        // Strong role-reveal screen: a role name plus reveal-style anchors.
        let isRoleReveal = phase == .roleReveal || RoleCatalog.normalize(joined).contains("yourrole") || RoleCatalog.normalize(joined).contains("你的身份")
        if isRoleReveal, let role = roleHits.first {
            let player = detectPlayerName(tokens: tokens, excludingRole: role)
            let target = player ?? "当前玩家"
            inference.addDirectRole(playerName: target, roleID: role.id, confidence: 0.99, reason: "当前画面直接出现身份：\(role.nameCN)")
        }

        let targetCandidate = chooseTarget(tokens: tokens)
        for match in ruleMatches where !match.possibleRoleIDs.isEmpty {
            if let target = targetCandidate {
                for roleID in match.possibleRoleIDs {
                    inference.addEvidence(playerName: target, roleID: roleID, weight: match.confidence * 0.85, kind: .visualSignal, reason: "检测到：\(match.label)")
                }
            }
        }

        // Map broad visual/event signals to any player name mentioned alongside them.
        let playerNames = extractPlayerNames(tokens: tokens)
        for name in playerNames {
            for match in ruleMatches where !match.possibleRoleIDs.isEmpty {
                for roleID in match.possibleRoleIDs {
                    inference.addEvidence(playerName: name, roleID: roleID, weight: match.confidence * 0.45, kind: .event, reason: "画面包含\(match.label)相关信息")
                }
            }
        }

        let hypotheses = targetCandidate.map { inference.infer(playerName: $0, topK: 3) } ?? []
        let players = inference.inferMany(playerNames: Array(playerNames.prefix(12)))
        let newEvents = makeEvents(phase: phase, ruleMatches: ruleMatches, alive: alive, tokens: tokens)

        let screenConfidence: Double = {
            var base = phase == .unknown ? 0.35 : 0.72
            if alive > 0 { base += 0.08 }
            if !ruleMatches.isEmpty { base += 0.10 }
            if !roleHits.isEmpty { base += 0.08 }
            return min(0.99, base)
        }()

        let targetLabel = hypotheses.first?.roleName
        let suggestion: String
        if let top = hypotheses.first, top.confidence >= 0.84 {
            suggestion = "\(top.roleName) 为当前最高置信候选；\(top.reasons.first ?? "等待更多证据")。"
        } else if !hypotheses.isEmpty {
            suggestion = "身份仍有多解，先记录事件，不要仅凭单帧锁定。"
        } else if phase == .meeting || phase == .voting {
            suggestion = "会议阶段：优先比较死亡时间、站位与投票信息。"
        } else {
            suggestion = "持续识别中；低置信度信息不会强制改变身份判断。"
        }

        return AnalyzerState(
            kind: ruleMatches.first?.eventID ?? phase.rawValue,
            phase: phaseLabel(phase),
            targetName: targetCandidate,
            confidence: screenConfidence,
            aliveCount: alive,
            suggestion: suggestion,
            detail: "OCR \(tokens.count) 项 · 规则命中 \(ruleMatches.count) · 候选角色 \(targetLabel ?? "无")",
            hypotheses: hypotheses,
            players: players,
            events: newEvents
        )
    }

    private func shouldRun() -> Bool {
        lock.lock(); defer { lock.unlock() }
        let now = Date()
        guard now.timeIntervalSince(lastRun) >= 0.40 else { return false }
        lastRun = now
        return true
    }

    private func detectPhase(_ text: String) -> RavenPhase {
        let t = RoleCatalog.normalize(text)
        if t.contains("投票") || t.contains("voting") || t.contains("skip") || t.contains("跳过") { lastPhase = .voting; return .voting }
        if t.contains("谁报告") || t.contains("who reported") || t.contains("讨论") || t.contains("发言") || t.contains("meeting") { lastPhase = .meeting; return .meeting }
        if t.contains("你的身份") || t.contains("yourrole") || t.contains("角色") && t.contains("开始") { lastPhase = .roleReveal; return .roleReveal }
        if t.contains("任务") || t.contains("tasks") || t.contains("破坏") || t.contains("sabotage") { lastPhase = .action; return .action }
        return lastPhase == .unknown ? .unknown : lastPhase
    }

    private func phaseLabel(_ phase: RavenPhase) -> String {
        switch phase {
        case .unknown: return "识别中"
        case .lobby: return "大厅"
        case .roleReveal: return "身份揭示"
        case .action: return "行动"
        case .meeting: return "会议"
        case .voting: return "投票"
        case .results: return "结算"
        }
    }

    private func detectAliveCount(_ tokens: [RavenOCRToken]) -> Int {
        let text = tokens.map(\.text).joined(separator: " ")
        let candidates = text.matches(for: #"(?:alive|存活|玩家|players?)\s*[:：]?\s*(\d{1,2})"#)
        if let first = candidates.first, let n = Int(first) { return n }
        return -1
    }

    private func detectPlayerName(tokens: [RavenOCRToken], excludingRole role: RavenRole) -> String? {
        let bad = Set([role.nameCN.lowercased(), role.nameEN.lowercased(), "your role", "你的身份", "鹅", "鸭", "中立"])
        return tokens.map(\.text).first { token in
            let trimmed = token.trimmingCharacters(in: .whitespacesAndNewlines)
            return trimmed.count >= 2 && !bad.contains(trimmed.lowercased()) && !trimmed.allSatisfy { $0.isNumber }
        }
    }

    private func chooseTarget(tokens: [RavenOCRToken]) -> String? {
        // Prefer names near a strong role signal. Without a player roster, return nil rather than invent a name.
        let roleNames = Set(catalog.roles.flatMap { [$0.nameCN, $0.nameEN] }.map { RoleCatalog.normalize($0) })
        return tokens.sorted { $0.boundingBox.maxY > $1.boundingBox.maxY }
            .map(\.text)
            .first { token in
                let n = RoleCatalog.normalize(token)
                return token.count >= 2 && !roleNames.contains(n) && !Self.genericWords.contains(n)
            }
    }

    private func extractPlayerNames(tokens: [RavenOCRToken]) -> Set<String> {
        let roleNames = Set(catalog.roles.flatMap { [$0.nameCN, $0.nameEN] }.map { RoleCatalog.normalize($0) })
        return Set(tokens.map(\.text).filter { text in
            let n = RoleCatalog.normalize(text)
            return text.count >= 2 && !roleNames.contains(n) && !Self.genericWords.contains(n) && !text.allSatisfy { $0.isNumber }
        }.prefix(12))
    }

    private func applyExplicitKillEvidence(tokens: [RavenOCRToken], ruleMatches: [RavenRuleMatch]) {
        let actorPatterns = [
            #"^(.{2,20})\s*(杀了|击杀|杀死|killed|killed)\s+(.{2,20})$"#,
            #"^(.{2,20})\s*(was killed by|被)\s*(.{2,20})$"#
        ]
        for token in tokens {
            for pattern in actorPatterns {
                guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { continue }
                let ns = token.text as NSString
                let range = NSRange(location: 0, length: ns.length)
                guard let match = regex.firstMatch(in: token.text, range: range), match.numberOfRanges >= 4 else { continue }
                let first = ns.substring(with: match.range(at: 1)).trimmingCharacters(in: .whitespaces)
                let third = ns.substring(with: match.range(at: 3)).trimmingCharacters(in: .whitespaces)
                let actor = pattern.contains("was killed by") ? third : first
                guard actor.count >= 2 else { continue }
                for role in catalog.roles where role.canKill {
                    inference.addEvidence(playerName: actor, roleID: role.id, weight: 0.42, kind: .event, reason: "画面文字明确描述其进行了击杀")
                }
                for role in catalog.roles where !role.canKill {
                    inference.addEvidence(playerName: actor, roleID: role.id, weight: -0.30, kind: .contradiction, reason: "画面文字明确描述其进行了击杀")
                }
                return
            }
        }
        _ = ruleMatches
    }

    private func makeEvents(phase: RavenPhase, ruleMatches: [RavenRuleMatch], alive: Int, tokens: [RavenOCRToken]) -> [RavenEvent] {
        var result: [RavenEvent] = []
        let now = Date()
        let minimumRepeatGap = 4.0
        for match in ruleMatches {
            if let previous = lastEventIDs[match.eventID], now.timeIntervalSince(previous) < minimumRepeatGap { continue }
            lastEventIDs[match.eventID] = now
            result.append(RavenEvent(kind: match.label, detail: "识别到关键词/视觉锚点：\(match.evidenceText)", confidence: match.confidence))
        }
        if phase == .meeting && !ruleMatches.contains(where: { $0.eventID == "meeting" }) {
            result.append(RavenEvent(kind: "meeting", detail: "会议界面特征", confidence: 0.72))
        }
        if alive > 0 {
            result.append(RavenEvent(kind: "alive", detail: "检测到存活人数：\(alive)", confidence: 0.82))
        }
        _ = tokens
        return result
    }

    private static let genericWords: Set<String> = [
        "投票", "voting", "skip", "跳过", "任务", "tasks", "设置", "settings", "报告", "report", "尸体", "body",
        "玩家", "players", "存活", "alive", "会议", "meeting", "发言", "讨论", "yourrole", "你的身份", "鹅", "鸭", "中立"
    ]
}

private extension String {
    func matches(for pattern: String) -> [String] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return [] }
        let ns = self as NSString
        return regex.matches(in: self, range: NSRange(location: 0, length: ns.length)).compactMap { match in
            guard match.numberOfRanges > 1 else { return nil }
            return ns.substring(with: match.range(at: 1))
        }
    }
}
