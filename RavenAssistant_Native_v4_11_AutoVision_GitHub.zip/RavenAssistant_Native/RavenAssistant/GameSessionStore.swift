import ActivityKit
import Combine
import Foundation

@MainActor
final class GameSessionStore: ObservableObject {
    @Published var isRunning = false
    @Published var captureStatus = "未启动"
    @Published var phase = "准备"
    @Published var target = "—"
    @Published var confidence = 0
    @Published var aliveCount = 0
    @Published var suggestion = "开始一局后，渡鸦会自动整理可见信息。"
    @Published var events: [RavenEvent] = []
    @Published var targetHypotheses: [RavenRoleHypothesis] = []
    @Published var playerInferences: [RavenPlayerInference] = []

    private(set) var liveActivity: Activity<RavenLiveActivityAttributes>?
    let capture = ScreenCaptureService()
    private let analyzer = VisionAnalyzer()

    func startSession() async {
        guard !isRunning else { return }
        isRunning = true
        captureStatus = "等待系统屏幕授权"
        analyzer.reset()
        events.removeAll()
        targetHypotheses.removeAll()
        playerInferences.removeAll()
        startLiveActivity()
        await capture.start { [weak self] sample in
            guard let self else { return }
            if let state = self.analyzer.analyze(sample) {
                Task { @MainActor [weak self] in
                    self?.apply(state)
                }
            }
        }
    }

    func stopSession() async {
        await capture.stop()
        liveActivity?.end(nil, dismissalPolicy: .immediate)
        liveActivity = nil
        isRunning = false
        captureStatus = "已停止"
    }

    private func startLiveActivity() {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            captureStatus = "Live Activity 未开启"
            return
        }
        let attributes = RavenLiveActivityAttributes(sessionID: UUID().uuidString, gameVersion: "v4.11", mode: "Auto")
        let state = RavenLiveActivityAttributes.ContentState(phase: phase, targetName: target, confidence: confidence, aliveCount: aliveCount, suggestion: suggestion, alertLevel: alertLevel)
        do {
            liveActivity = try Activity.request(attributes: attributes, content: .init(state: state, staleDate: Date(timeIntervalSinceNow: 30)), pushType: nil)
        } catch {
            captureStatus = "无法启动 Live Activity：\(error.localizedDescription)"
        }
    }

    private var alertLevel: String {
        if confidence >= 85 { return "high" }
        if confidence >= 60 { return "medium" }
        return "low"
    }

    private func apply(_ state: AnalyzerState) {
        phase = state.phase
        confidence = Int((state.confidence * 100).rounded())
        if state.aliveCount >= 0 { aliveCount = state.aliveCount }
        if let t = state.targetName { target = t }
        if !state.suggestion.isEmpty { suggestion = state.suggestion }
        targetHypotheses = state.hypotheses
        playerInferences = state.players
        if !state.events.isEmpty {
            events.insert(contentsOf: state.events.reversed(), at: 0)
            if events.count > 200 { events.removeLast(events.count - 200) }
        }
        if let first = state.events.first {
            events.insert(RavenEvent(kind: state.kind, player: state.targetName, detail: first.detail, confidence: state.confidence), at: 0)
            if events.count > 200 { events.removeLast(events.count - 200) }
        }
        Task { await updateLiveActivity() }
    }

    private func updateLiveActivity() async {
        guard let activity = liveActivity else { return }
        let content = ActivityContent(
            state: RavenLiveActivityAttributes.ContentState(phase: phase, targetName: target, confidence: confidence, aliveCount: aliveCount, suggestion: suggestion, alertLevel: alertLevel),
            staleDate: Date(timeIntervalSinceNow: 30)
        )
        await activity.update(content)
    }
}
