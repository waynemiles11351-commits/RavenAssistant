import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var session: GameSessionStore
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            DashboardView().tabItem { Label("战局", systemImage: "scope") }.tag(0)
            RolesView().tabItem { Label("角色", systemImage: "person.3") }.tag(1)
            TimelineView().tabItem { Label("事件", systemImage: "clock.arrow.circlepath") }.tag(2)
            SettingsView().tabItem { Label("设置", systemImage: "gearshape") }.tag(3)
        }
        .tint(.white)
    }
}

struct DashboardView: View {
    @EnvironmentObject private var session: GameSessionStore
    @State private var showStopConfirm = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    header
                    statusCard
                    targetCard
                    inferenceCard
                    captureCard
                    latestEvents
                }
                .padding(16)
            }
            .navigationTitle("渡鸦")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Text("v4.11").font(.caption).foregroundStyle(.secondary) } }
        }
        .confirmationDialog("停止本局？", isPresented: $showStopConfirm) {
            Button("停止", role: .destructive) { Task { await session.stopSession() } }
            Button("继续", role: .cancel) {}
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("自动辅助").font(.title2.bold())
                Text(session.isRunning ? "正在工作" : "尚未开始").foregroundStyle(.secondary)
            }
            Spacer()
            Circle().fill(session.isRunning ? Color.green : Color.gray).frame(width: 10, height: 10)
        }
    }

    private var statusCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(session.phase, systemImage: "waveform.path.ecg")
                .font(.headline)
            HStack {
                metric("存活", session.aliveCount > 0 ? "\(session.aliveCount)" : "—")
                Divider().frame(height: 32)
                metric("可信度", "\(session.confidence)%")
            }
            Text(session.suggestion).font(.subheadline).foregroundStyle(.secondary)
        }
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
    }

    private var targetCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("当前关注").font(.caption).foregroundStyle(.secondary)
            HStack(alignment: .firstTextBaseline) {
                Text(session.target).font(.system(size: 30, weight: .bold))
                Spacer()
                Text("\(session.confidence)%").font(.headline)
            }
            ProgressView(value: Double(session.confidence), total: 100)
        }
        .padding()
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
    }

    private var inferenceCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("角色推断").font(.headline)
            if session.targetHypotheses.isEmpty {
                Text("暂无足够证据").font(.footnote).foregroundStyle(.secondary)
            } else {
                ForEach(Array(session.targetHypotheses.prefix(3))) { h in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(h.roleName).font(.subheadline.bold())
                            Text(h.faction == .goose ? "鹅" : h.faction == .duck ? "鸭" : "中立")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text("\(Int(h.confidence * 100))%")
                            .font(.subheadline.monospacedDigit())
                        }
                    if let reason = h.reasons.first {
                        Text(reason).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                Text("概率来自多次证据累积，不代表隐藏身份已被直接读取。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
    }

    private var captureCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("屏幕采集").font(.headline)
                Spacer()
                Text(session.captureStatus).font(.caption).foregroundStyle(.secondary)
            }
            Text("需要你主动通过 iOS 系统授权整个屏幕。识别结果优先在本机处理。")
                .font(.footnote).foregroundStyle(.secondary)
            Button {
                Task {
                    if session.isRunning { showStopConfirm = true }
                    else { await session.startSession() }
                }
            } label: {
                Text(session.isRunning ? "结束辅助" : "开始辅助")
                    .frame(maxWidth: .infinity).padding(.vertical, 12)
                    .background(session.isRunning ? Color.red.opacity(0.8) : Color.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
        }
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
    }

    private var latestEvents: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("最近事件").font(.headline)
            if session.events.isEmpty {
                Text("还没有可靠事件").foregroundStyle(.secondary)
            } else {
                ForEach(Array(session.events.prefix(4))) { event in
                    HStack {
                        Circle().fill(.white.opacity(0.7)).frame(width: 7, height: 7)
                        Text(event.detail).lineLimit(1)
                        Spacer()
                        Text("\(Int(event.confidence * 100))%").font(.caption).foregroundStyle(.secondary)
                    }
                    .font(.footnote)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func metric(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading) { Text(title).font(.caption).foregroundStyle(.secondary); Text(value).font(.headline) }
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct RolesView: View {
    @State private var query = ""
    private let roles = RoleCatalog.shared.roles

    var body: some View {
        NavigationStack {
            List(filtered) { role in
                VStack(alignment: .leading, spacing: 5) {
                    HStack {
                        Text(role.nameCN).font(.headline)
                        Spacer()
                        Text(role.faction == .goose ? "鹅" : role.faction == .duck ? "鸭" : "中立")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Text(role.nameEN).font(.caption).foregroundStyle(.secondary)
                    Text(role.ability).font(.footnote).lineLimit(2)
                }
                .padding(.vertical, 4)
            }
            .searchable(text: $query, prompt: "搜索角色 / 技能")
            .navigationTitle("角色库 · \(roles.count)")
        }
    }

    private var filtered: [RavenRole] {
        guard !query.isEmpty else { return roles }
        return roles.filter { [$0.nameCN, $0.nameEN, $0.ability].joined(separator: " ").localizedCaseInsensitiveContains(query) }
    }
}

struct TimelineView: View {
    @EnvironmentObject private var session: GameSessionStore
    var body: some View {
        NavigationStack {
            List(session.events) { e in
                VStack(alignment: .leading, spacing: 4) {
                    HStack { Text(e.kind); Spacer(); Text("\(Int(e.confidence * 100))%") }
                    Text(e.detail).font(.footnote)
                    Text(e.time.formatted(date: .omitted, time: .standard)).font(.caption2).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("事件时间线")
        }
    }
}

struct SettingsView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("识别策略") {
                    LabeledContent("当前基线", value: "v4.11")
                    LabeledContent("当前角色基线", value: "62")
                    LabeledContent("旧版/地图角色", value: "已保留，默认禁用")
                }
                Section("安全") {
                    Text("不会修改游戏进程、注入代码或自动操作角色。屏幕识别以系统授权的采集流为输入。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("设置")
        }
    }
}
